from flask import Flask, render_template

app = Flask(__name__, static_folder='static')

@app.route('/')
def home():
    return render_template('front.html')

@app.route('/front.html')
def front():
    return render_template('front.html')

@app.route('/login.html')
def login():
    return render_template('login.html')

@app.route('/register.html')
def register():
    return render_template('register.html')

@app.route('/about.html')
def about():
    return render_template('about.html')

@app.route('/service.html')
def service():
    return render_template('service.html')

@app.route('/property.html')
def property():
    return render_template('property.html')

@app.route('/card1.html')
def card1():
    return render_template('card1.html')

@app.route('/card2.html')
def card2():
    return render_template('card2.html')

@app.route('/card3.html')
def card3():
    return render_template('card3.html')

@app.route('/blog.html')
def blog():
    return render_template('blog.html')

@app.route('/contact.html')
def contact():
    return render_template('contact.html')

if __name__ == '__main__':
    app.run(debug=True)